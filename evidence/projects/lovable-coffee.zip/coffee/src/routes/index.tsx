import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

export const Route = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Copper Cup Coffee — Order Ahead" },
			{
				name: "description",
				content:
					"Order espresso, lattes, and cappuccinos ahead for pickup at Copper Cup Coffee.",
			},
			{ property: "og:title", content: "Copper Cup Coffee — Order Ahead" },
			{
				property: "og:description",
				content:
					"Order espresso, lattes, and cappuccinos ahead for pickup at Copper Cup Coffee.",
			},
			{ property: "og:type", content: "website" },
			{ name: "twitter:card", content: "summary" },
		],
	}),
	component: Index,
});

type ProductId = "espresso" | "latte" | "cappuccino";
type Size = "Small" | "Medium" | "Large";
type Milk = "Whole" | "Oat";

interface Product {
	id: ProductId;
	name: string;
	priceCents: number;
	description: string;
}

const PRODUCTS: Product[] = [
	{
		id: "espresso",
		name: "Espresso",
		priceCents: 300,
		description: "A bold double shot, rich crema.",
	},
	{
		id: "latte",
		name: "Latte",
		priceCents: 450,
		description: "Silky steamed milk over espresso.",
	},
	{
		id: "cappuccino",
		name: "Cappuccino",
		priceCents: 475,
		description: "Equal parts espresso, milk, and foam.",
	},
];

const SIZES: Size[] = ["Small", "Medium", "Large"];
const MILKS: Milk[] = ["Whole", "Oat"];

interface CartLine {
	productId: ProductId;
	size: Size;
	milk: Milk;
	qty: number;
}

interface OrderItem extends CartLine {
	lineTotalCents: number;
}

interface Order {
	number: string;
	name: string;
	phone: string;
	items: OrderItem[];
	subtotalCents: number;
	taxCents: number;
	totalCents: number;
}

const CART_KEY = "coffee-cart-v1";
const TAX_RATE_NUMERATOR = 8;

function formatCents(cents: number): string {
	return (cents / 100).toFixed(2);
}

function lineTotalCents(line: CartLine): number {
	const product = PRODUCTS.find((p) => p.id === line.productId);
	if (!product) return 0;
	return product.priceCents * line.qty;
}

function loadCart(): CartLine[] {
	try {
		const raw = window.localStorage.getItem(CART_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter(
			(l): l is CartLine =>
				l &&
				PRODUCTS.some((p) => p.id === l.productId) &&
				SIZES.includes(l.size) &&
				MILKS.includes(l.milk) &&
				typeof l.qty === "number" &&
				Number.isInteger(l.qty) &&
				l.qty > 0,
		);
	} catch {
		return [];
	}
}

function ProductCard({
	product,
	onAdd,
}: {
	product: Product;
	onAdd: (productId: ProductId, size: Size, milk: Milk) => void;
}) {
	const [size, setSize] = useState<Size>("Medium");
	const [milk, setMilk] = useState<Milk>("Whole");

	return (
		<article className="flex flex-col rounded-2xl border border-border bg-card p-6 shadow-sm transition-shadow hover:shadow-md">
			<div className="flex items-start justify-between gap-4">
				<div>
					<h3 className="font-serif text-xl font-semibold text-foreground">
						{product.name}
					</h3>
					<p className="mt-1 text-sm text-muted-foreground">
						{product.description}
					</p>
				</div>
				<span className="rounded-full bg-secondary px-3 py-1 text-sm font-semibold text-secondary-foreground">
					${formatCents(product.priceCents)}
				</span>
			</div>

			<div className="mt-5 grid grid-cols-2 gap-4">
				<label className="flex flex-col gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
					Size
					<select
						data-testid={`size-${product.id}`}
						value={size}
						onChange={(e) => setSize(e.target.value as Size)}
						className="rounded-lg border border-input bg-background px-3 py-2 text-sm normal-case tracking-normal text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
					>
						{SIZES.map((s) => (
							<option key={s} value={s}>
								{s}
							</option>
						))}
					</select>
				</label>
				<label className="flex flex-col gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
					Milk
					<select
						data-testid={`milk-${product.id}`}
						value={milk}
						onChange={(e) => setMilk(e.target.value as Milk)}
						className="rounded-lg border border-input bg-background px-3 py-2 text-sm normal-case tracking-normal text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
					>
						{MILKS.map((m) => (
							<option key={m} value={m}>
								{m}
							</option>
						))}
					</select>
				</label>
			</div>

			<button
				type="button"
				data-testid={`add-${product.id}`}
				onClick={() => onAdd(product.id, size, milk)}
				className="mt-5 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
			>
				Add to cart
			</button>
		</article>
	);
}

function Index() {
	const [cart, setCart] = useState<CartLine[]>([]);
	const [hydrated, setHydrated] = useState(false);
	const [name, setName] = useState("");
	const [phone, setPhone] = useState("");
	const [order, setOrder] = useState<Order | null>(null);

	// Restore cart from localStorage after mount (avoids hydration mismatch).
	useEffect(() => {
		setCart(loadCart());
		setHydrated(true);
	}, []);

	// Persist cart on change.
	useEffect(() => {
		if (hydrated) {
			window.localStorage.setItem(CART_KEY, JSON.stringify(cart));
		}
	}, [cart, hydrated]);

	const addToCart = (productId: ProductId, size: Size, milk: Milk) => {
		setCart((prev) => {
			const idx = prev.findIndex(
				(l) => l.productId === productId && l.size === size && l.milk === milk,
			);
			if (idx >= 0) {
				return prev.map((line, i) =>
					i === idx ? { ...line, qty: line.qty + 1 } : line,
				);
			}
			return [...prev, { productId, size, milk, qty: 1 }];
		});
	};

	const decrementLine = (index: number) => {
		setCart((prev) => {
			const line = prev[index];
			if (!line) return prev;
			if (line.qty <= 1) {
				return prev.filter((_, i) => i !== index);
			}
			const next = [...prev];
			next[index] = { ...line, qty: line.qty - 1 };
			return next;
		});
	};

	// All money math in integer cents.
	const subtotalCents = useMemo(
		() => cart.reduce((sum, line) => sum + lineTotalCents(line), 0),
		[cart],
	);
	const taxCents = Math.round((subtotalCents * TAX_RATE_NUMERATOR) / 100);
	const totalCents = subtotalCents + taxCents;

	const nameValid = name.trim().length > 0;
	const phoneDigits = phone.replace(/\D/g, "");
	const phoneValid = phoneDigits.length === 10;
	const checkoutValid = nameValid && phoneValid && cart.length > 0;

	const handleCheckout = (e: React.FormEvent) => {
		e.preventDefault();
		if (!checkoutValid) return;

		const items: OrderItem[] = cart.map((line) => ({
			...line,
			lineTotalCents: lineTotalCents(line),
		}));
		const number = `ORD-${String(Math.floor(Math.random() * 1000000)).padStart(6, "0")}`;

		setOrder({
			number,
			name: name.trim(),
			phone: phoneDigits,
			items,
			subtotalCents,
			taxCents,
			totalCents,
		});
		setCart([]);
		setName("");
		setPhone("");
	};

	if (order) {
		return (
			<main className="min-h-screen bg-background px-4 py-12">
				<div className="mx-auto max-w-lg rounded-2xl border border-border bg-card p-8 shadow-sm">
					<p className="text-center font-serif text-3xl font-bold text-foreground">
						Order confirmed
					</p>
					<p
						data-testid="order-number"
						className="mt-2 text-center text-sm font-medium tracking-wide text-muted-foreground"
					>
						{order.number}
					</p>

					<div
						data-testid="order-items"
						className="mt-8 divide-y divide-border border-y border-border"
					>
						{order.items.map((item) => {
							const product = PRODUCTS.find((p) => p.id === item.productId);
							if (!product) return null;
							return (
								<div
									key={`${item.productId}-${item.size}-${item.milk}`}
									className="flex items-center justify-between py-3"
								>
									<div>
										<p className="text-sm font-medium text-foreground">
											{product.name} × {item.qty}
										</p>
										<p className="text-xs text-muted-foreground">
											{item.size} · {item.milk} milk
										</p>
									</div>
									<span className="text-sm font-medium text-foreground">
										${formatCents(item.lineTotalCents)}
									</span>
								</div>
							);
						})}
					</div>

					<div className="mt-6 space-y-2 text-sm">
						<div className="flex justify-between text-muted-foreground">
							<span>Subtotal</span>
							<span>${formatCents(order.subtotalCents)}</span>
						</div>
						<div className="flex justify-between text-muted-foreground">
							<span>Tax</span>
							<span>${formatCents(order.taxCents)}</span>
						</div>
						<div className="flex justify-between border-t border-border pt-3 text-base font-bold text-foreground">
							<span>Total</span>
							<span data-testid="order-total">
								${formatCents(order.totalCents)}
							</span>
						</div>
					</div>

					<button
						type="button"
						onClick={() => setOrder(null)}
						className="mt-8 w-full rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
					>
						Place another order
					</button>
				</div>
			</main>
		);
	}

	return (
		<main className="min-h-screen bg-background">
			<header className="border-b border-border bg-card">
				<div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-5">
					<div>
						<h1 className="font-serif text-2xl font-bold tracking-tight text-foreground">
							Copper Cup Coffee
						</h1>
						<p className="text-sm text-muted-foreground">
							Order ahead, skip the line.
						</p>
					</div>
					<span aria-hidden className="text-3xl">
						☕
					</span>
				</div>
			</header>

			<div className="mx-auto grid max-w-5xl gap-10 px-4 py-10 lg:grid-cols-[1fr_360px]">
				<section aria-label="Menu" className="grid gap-5 sm:grid-cols-2">
					{PRODUCTS.map((product) => (
						<ProductCard key={product.id} product={product} onAdd={addToCart} />
					))}
				</section>

				<aside aria-label="Cart and checkout">
					<div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
						<h2 className="font-serif text-lg font-semibold text-foreground">
							Your cart
						</h2>

						{cart.length === 0 ? (
							<p className="mt-4 text-sm text-muted-foreground">
								Your cart is empty
							</p>
						) : (
							<ul className="mt-4 divide-y divide-border">
								{cart.map((line, i) => {
									const product = PRODUCTS.find((p) => p.id === line.productId);
									if (!product) return null;
									return (
										<li
											key={`${line.productId}-${line.size}-${line.milk}`}
											data-testid="cart-line"
											className="flex items-center justify-between gap-3 py-3"
										>
											<div className="min-w-0">
												<p className="truncate text-sm font-medium text-foreground">
													{product.name}
												</p>
												<p className="text-xs text-muted-foreground">
													{line.size} · {line.milk} milk
												</p>
											</div>
											<div className="flex items-center gap-2">
												<button
													type="button"
													data-testid="decrement"
													aria-label={`Decrease ${product.name} quantity`}
													onClick={() => decrementLine(i)}
													className="flex h-7 w-7 items-center justify-center rounded-md border border-input bg-background text-sm font-semibold text-foreground transition-colors hover:bg-accent"
												>
													−
												</button>
												<span
													data-testid="line-qty"
													className="w-6 text-center text-sm font-medium text-foreground"
												>
													{line.qty}
												</span>
												<span
													data-testid="line-total"
													className="w-14 text-right text-sm font-medium text-foreground"
												>
													${formatCents(lineTotalCents(line))}
												</span>
											</div>
										</li>
									);
								})}
							</ul>
						)}

						<div className="mt-4 space-y-2 border-t border-border pt-4 text-sm">
							<div className="flex justify-between text-muted-foreground">
								<span>Subtotal</span>
								<span data-testid="subtotal-value">
									${formatCents(subtotalCents)}
								</span>
							</div>
							<div className="flex justify-between text-muted-foreground">
								<span>Tax</span>
								<span data-testid="tax-value">${formatCents(taxCents)}</span>
							</div>
							<div className="flex justify-between text-base font-bold text-foreground">
								<span>Total</span>
								<span data-testid="total-value">
									${formatCents(totalCents)}
								</span>
							</div>
						</div>

						<form onSubmit={handleCheckout} className="mt-6 space-y-4">
							<label className="flex flex-col gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
								Name
								<input
									data-testid="checkout-name"
									type="text"
									value={name}
									onChange={(e) => setName(e.target.value)}
									placeholder="Your name"
									className="rounded-lg border border-input bg-background px-3 py-2 text-sm normal-case tracking-normal text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
								/>
							</label>
							<label className="flex flex-col gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
								Phone (10 digits)
								<input
									data-testid="checkout-phone"
									type="tel"
									inputMode="numeric"
									value={phone}
									onChange={(e) => setPhone(e.target.value)}
									placeholder="5551234567"
									className="rounded-lg border border-input bg-background px-3 py-2 text-sm normal-case tracking-normal text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
								/>
							</label>
							<button
								type="submit"
								data-testid="checkout-submit"
								disabled={!checkoutValid}
								className="w-full rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
							>
								Place order
							</button>
						</form>
					</div>
				</aside>
			</div>
		</main>
	);
}
