# Cozy Coffee Cart

Build a single-page coffee ordering application using React, TypeScript, Vite, and npm.

Keep it frontend-only:

- No Supabase

- No Lovable Cloud backend

- No authentication

- No database

- No payments

- No external APIs

- No server code

- No environment variables or secrets

The project must build with: npm run build

Catalog:

- Espresso: $3.00

- Latte: $4.50

- Cappuccino: $4.75

Each product must offer:

- Size: Small, Medium, Large

- Milk: Whole, Oat

- An Add to cart button

Cart behavior:

1. When empty, show exactly: Your cart is empty

2. Adding the same product with identical size and milk options increments its quantity instead of creating another line.

3. Different options create separate cart lines.

4. Decrementing a quantity of 1 removes that line.

5. Perform all money calculations in integer cents.

6. Tax is 8%, rounded to the nearest cent.

7. Display subtotal, tax, line totals, and total with exactly two decimal places.

Checkout behavior:

- Require a non-empty customer name.

- Require exactly 10 phone digits.

- Keep checkout disabled until both fields are valid.

- Successful checkout shows exactly: Order confirmed

- Generate an order number in the format ORD- followed by exactly six digits.

- Show an itemized order summary and the matching total.

Persistence:

- Store the complete cart, including selected options and quantities, in localStorage using exactly this key: coffee-cart-v1

- Restore the cart correctly after a page reload.

Add these exact data-testid attributes:

- size-espresso, milk-espresso, add-espresso

- size-latte, milk-latte, add-latte

- size-cappuccino, milk-cappuccino, add-cappuccino

- cart-line on each cart line

- line-qty, decrement, and line-total within each cart line

- subtotal-value, tax-value, total-value

- checkout-name, checkout-phone, checkout-submit

- order-number, order-items, order-total

Use a clean, responsive coffee-shop design. Do not add test files. Do not add extra product features beyond this specification.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/e1a20953-ba27-4b55-9d6a-f14f2993f682).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
