# Daily Wins Tracker

Build a small frontend-only habit tracker using React, TypeScript, Vite, and npm. Users can add habits, mark them complete for today, delete them, and retain them across reloads using localStorage. Use no backend, authentication, database, external API, environment variables, or secrets. Ensure npm run build succeeds. Keep the implementation simple and responsive.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/68f7dbe5-2276-4d3b-b3c3-c04d56d16ed5).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
