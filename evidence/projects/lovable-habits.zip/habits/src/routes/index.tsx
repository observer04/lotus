import { createFileRoute } from "@tanstack/react-router";
import { format } from "date-fns";
import { CalendarDays, CheckCircle2, Circle, Plus, Trash2 } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

const STORAGE_KEY = "habit-tracker-data";

type Habit = {
	id: string;
	name: string;
	completedDates: string[];
	createdAt: number;
};

function getToday(): string {
	return format(new Date(), "yyyy-MM-dd");
}

function loadHabits(): Habit[] {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw) as Habit[];
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}

function saveHabits(habits: Habit[]): void {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(habits));
	} catch {
		// Ignore storage errors (e.g. private mode).
	}
}

export const Route = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Habit Tracker" },
			{ name: "description", content: "A simple daily habit tracker." },
			{ property: "og:title", content: "Habit Tracker" },
			{
				property: "og:description",
				content: "Track your daily habits and build consistency.",
			},
			{ property: "og:type", content: "website" },
			{ name: "twitter:card", content: "summary" },
		],
	}),
	component: Index,
});

function Index() {
	const [habits, setHabits] = useState<Habit[]>([]);
	const [newHabitName, setNewHabitName] = useState("");
	const [isReady, setIsReady] = useState(false);
	const inputRef = useRef<HTMLInputElement>(null);

	useEffect(() => {
		setHabits(loadHabits());
		setIsReady(true);
	}, []);

	useEffect(() => {
		if (!isReady) return;
		saveHabits(habits);
	}, [habits, isReady]);

	const today = getToday();

	const completedCount = useMemo(
		() => habits.filter((h) => h.completedDates.includes(today)).length,
		[habits, today],
	);

	const progress = useMemo(
		() =>
			habits.length > 0
				? Math.round((completedCount / habits.length) * 100)
				: 0,
		[completedCount, habits.length],
	);

	function handleAddHabit(e?: React.FormEvent) {
		e?.preventDefault();
		const name = newHabitName.trim();
		if (!name) return;

		const habit: Habit = {
			id: crypto.randomUUID(),
			name,
			completedDates: [],
			createdAt: Date.now(),
		};

		setHabits((prev) => [habit, ...prev]);
		setNewHabitName("");
		inputRef.current?.focus();
	}

	function toggleHabit(id: string) {
		setHabits((prev) =>
			prev.map((habit) => {
				if (habit.id !== id) return habit;
				const isCompleted = habit.completedDates.includes(today);
				return {
					...habit,
					completedDates: isCompleted
						? habit.completedDates.filter((d) => d !== today)
						: [...habit.completedDates, today],
				};
			}),
		);
	}

	function deleteHabit(id: string) {
		setHabits((prev) => prev.filter((h) => h.id !== id));
	}

	return (
		<main className="min-h-screen bg-background px-4 py-8 sm:py-12">
			<div className="mx-auto max-w-xl">
				<Card>
					<CardHeader className="space-y-1">
						<div className="flex items-center justify-between gap-4">
							<CardTitle className="text-2xl font-bold tracking-tight sm:text-3xl">
								Habit Tracker
							</CardTitle>
							<div className="flex items-center gap-2 text-sm text-muted-foreground">
								<CalendarDays className="h-4 w-4" />
								<span>{format(new Date(), "EEEE, MMMM do")}</span>
							</div>
						</div>
						<p className="text-sm text-muted-foreground">
							Build better routines, one day at a time.
						</p>
					</CardHeader>

					<CardContent className="space-y-6">
						<form
							onSubmit={handleAddHabit}
							className="flex flex-col gap-2 sm:flex-row"
						>
							<Input
								ref={inputRef}
								value={newHabitName}
								onChange={(e) => setNewHabitName(e.target.value)}
								placeholder="Add a new habit..."
								className="flex-1"
								aria-label="New habit name"
							/>
							<Button type="submit" disabled={!newHabitName.trim()}>
								<Plus className="mr-2 h-4 w-4" />
								Add
							</Button>
						</form>

						{!isReady ? (
							<div className="space-y-3">
								<div className="h-12 animate-pulse rounded-md bg-muted" />
								<div className="h-12 animate-pulse rounded-md bg-muted" />
								<div className="h-12 animate-pulse rounded-md bg-muted" />
							</div>
						) : habits.length === 0 ? (
							<div className="rounded-lg border border-dashed border-border p-8 text-center">
								<p className="text-muted-foreground">
									No habits yet. Add one above to get started.
								</p>
							</div>
						) : (
							<>
								<div className="space-y-2">
									<div className="flex items-center justify-between text-sm">
										<span className="text-muted-foreground">
											Today&apos;s progress
										</span>
										<span className="font-medium">
											{completedCount} of {habits.length} completed
										</span>
									</div>
									<Progress
										value={progress}
										aria-label="Daily habit progress"
									/>
								</div>

								<ul className="space-y-2" role="list" aria-label="Habits">
									{habits.map((habit) => {
										const isCompleted = habit.completedDates.includes(today);
										return (
											<li
												key={habit.id}
												className="flex items-center gap-3 rounded-lg border border-border bg-card p-3 transition-colors hover:bg-accent/50"
											>
												<Checkbox
													id={`habit-${habit.id}`}
													checked={isCompleted}
													onCheckedChange={() => toggleHabit(habit.id)}
													aria-label={`Mark ${habit.name} as ${isCompleted ? "incomplete" : "complete"}`}
												/>
												<label
													htmlFor={`habit-${habit.id}`}
													className="flex flex-1 cursor-pointer items-center gap-2"
												>
													{isCompleted ? (
														<CheckCircle2 className="h-5 w-5 text-primary" />
													) : (
														<Circle className="h-5 w-5 text-muted-foreground" />
													)}
													<span
														className={`flex-1 text-sm font-medium ${
															isCompleted
																? "text-muted-foreground line-through"
																: "text-foreground"
														}`}
													>
														{habit.name}
													</span>
												</label>
												<Button
													variant="ghost"
													size="icon"
													onClick={() => deleteHabit(habit.id)}
													aria-label={`Delete ${habit.name}`}
													className="shrink-0 text-muted-foreground hover:text-destructive"
												>
													<Trash2 className="h-4 w-4" />
												</Button>
											</li>
										);
									})}
								</ul>
							</>
						)}
					</CardContent>
				</Card>
			</div>
		</main>
	);
}
